// ==UserScript==
// @name         Remove Join button
// @namespace    http://tampermonkey.net/
// @version      2025-08-18
// @description  try to take over the world!
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // The ID of the element we want to remove.
    const TARGET_ID = 'sponsor-button';

    // --- Observer Implementation ---

    // 1. Define the function that will be called when mutations are observed.
    const callback = function(mutationsList, observer) {
        // We can simply check for the element's existence and remove it.
        const sponsorButton = document.getElementById(TARGET_ID);
        if (sponsorButton) {
            sponsorButton.remove();
            // Optional: You could log to the console to confirm removal.
            // console.log('Sponsor button removed.');
        }
    };

    // 2. Create an observer instance linked to the callback function.
    const observer = new MutationObserver(callback);

    // 3. Configuration for the observer:
    // We need to watch for nodes being added/removed (childList)
    // and do this for the entire page subtree.
    const config = {
        childList: true,
        subtree: true
    };

    // 4. Start observing the target node (the entire document body) for configured mutations.
    // This ensures we catch the button whenever YouTube adds it to the page.
    observer.observe(document.body, config);

})();