// ==UserScript==
// @name         Remove YouTube Topic Filter Bar
// @namespace    http://tampermonkey.net/
// @version      2025-08-18
// @description  Removes the topic filter bar (All, Gaming, Music, etc.) from the YouTube homepage.
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Selectors for the elements we need to interact with
    const filterBarSelector = 'ytd-rich-grid-renderer > div#header';
    const mainHeaderSelector = 'div#frosted-glass';

    // A flag to ensure our code only runs once
    let hasBeenModified = false;

    const callback = function(mutationsList, observer) {
        // If the modification has already been made, do nothing.
        if (hasBeenModified) {
            return;
        }

        const filterBar = document.querySelector(filterBarSelector);
        const mainHeader = document.querySelector(mainHeaderSelector);

        // We must wait until BOTH elements are available on the page to perform the calculation
        if (filterBar && mainHeader) {
            console.log('Both elements found. Performing dynamic resize.');

            // 1. Get the rendered heights of both elements in pixels
            const filterBarHeight = filterBar.offsetHeight;
            const mainHeaderHeight = mainHeader.offsetHeight;

            // Make sure we have valid, non-zero heights before calculating
            if (filterBarHeight > 0 && mainHeaderHeight > 0) {
                // 2. Calculate the new height for the main header
                const newHeaderHeight = mainHeaderHeight - filterBarHeight;

                console.log(`Original header: ${mainHeaderHeight}px, Filter bar: ${filterBarHeight}px`);
                console.log(`Setting new header height to: ${newHeaderHeight}px`);

                // 3. Apply the newly calculated height to the main header
                mainHeader.style.height = `${newHeaderHeight}px`;

                // 4. Remove the filter bar
                filterBar.remove();

                // 5. Set our flag to true and disconnect the observer to save resources
                hasBeenModified = true;
                observer.disconnect();
                console.log('Modification complete. Observer disconnected.');
            }
        }
    };

    // Create an observer instance linked to the callback function
    const observer = new MutationObserver(callback);

    // Start observing the entire document for changes
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
})();