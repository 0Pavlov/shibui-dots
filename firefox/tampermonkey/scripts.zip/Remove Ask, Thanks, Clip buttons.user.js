// ==UserScript==
// @name         Remove Ask, Thanks, Clip buttons
// @namespace    http://tampermonkey.net/
// @version      2025-08-18
// @description  try to take over the world!
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // The ID of the container we want to completely remove.
    const selectorToRemove = 'flexible-item-buttons';

    const observerCallback = (mutationsList, observer) => {
        const buttonContainer = document.getElementById(selectorToRemove);

        // If the container is found...
        if (buttonContainer) {
            console.log('Flexible action buttons container found. Removing it.');
            buttonContainer.remove(); // ...remove it entirely.

            // The job is done, so we stop the observer to save resources.
            observer.disconnect();
        }
    };

    // Create and start the MutationObserver.
    const observer = new MutationObserver(observerCallback);
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
})();