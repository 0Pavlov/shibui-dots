// ==UserScript==
// @name         YouTube Guide Background Color
// @namespace    http://tampermonkey.net/
// @version      2025-08-18
// @description  Changes the background color of the YouTube guide drawer
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to find the element and change its background color
    const changeBackgroundColor = () => {
        // The element is <tp-yt-app-drawer id="guide">
        const guideElement = document.getElementById('guide');

        // Check if the element exists to avoid errors
        if (!guideElement.style.backgroundColor) {
            guideElement.style.backgroundColor = '#0f0f0f';
        }
    };

    // A MutationObserver to act when new elements are added to the page
    const observer = new MutationObserver(changeBackgroundColor);

    // Start observing the entire document for changes
    // The 'childList' option detects when nodes are added or removed
    // The 'subtree' option extends the observation to all descendants of the target
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // Also run the function once at the start in case the element
    // is already present when the script injects
    changeBackgroundColor();

})();