// ==UserScript==
// @name         Remove Metadata Under The Video
// @namespace    http://tampermonkey.net/
// @version      2025-08-18
// @description  try to take over the world!
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // This is the specific element tag we want to remove.
    const selectorToRemove = 'ytd-rich-metadata-row-renderer';

    const callback = function(mutationsList, observer) {
        const metadataBox = document.querySelector(selectorToRemove);

        // If the metadata box is found on the page...
        if (metadataBox) {
            console.log('Rich metadata box found. Removing it.');
            metadataBox.remove(); // ...remove it.

            // Since this script's job is done, we can stop observing for changes.
            observer.disconnect();
        }
    };

    // Create our observer to watch for page changes.
    const observer = new MutationObserver(callback);

    // Start observing the entire document for newly added elements.
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
})();