// ==UserScript==
// @name         Remove the Show Support button
// @namespace    http://tampermonkey.net/
// @version      2025-08-18
// @description  try to take over the world!
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const observer = new MutationObserver((mutationsList, observer) => {
        for(const mutation of mutationsList) {
            if (mutation.type === 'childList') {
                const productPicker = document.getElementById('product-picker');
                if (productPicker) {
                    productPicker.remove();
                    observer.disconnect(); // Stop observing once the element is found and removed
                }
            }
        }
    });

    // Start observing the document body for added nodes
    observer.observe(document.body, { childList: true, subtree: true });
})();