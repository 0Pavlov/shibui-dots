// ==UserScript==
// @name         Remove Shop Button
// @namespace    http://tampermonkey.net/
// @version      2025-08-18
// @description  try to take over the world!
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const observer = new MutationObserver((mutationsList, observer) => {
        for(const mutation of mutationsList) {
            if (mutation.type === 'childList') {
                const shopButton = document.querySelector('button[title="Shop"]');
                if (shopButton) {
                    shopButton.remove();
                    observer.disconnect(); // Stop observing once the button is removed
                }
            }
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
})();