// ==UserScript==
// @name         Adjust YouTube Video Container Margins
// @namespace    http://tampermonkey.net/
// @version      2025-08-21
// @description  Sets margins for the YouTube container and adjusts it on the main page, video watching and for fullscreen mode
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const targetSelector = '#page-manager.style-scope.ytd-app';
    let marginIntervalId = null;

    // This function applies the standard margins when NOT in fullscreen
    const applyDefaultStyles = () => {
        const element = document.querySelector(targetSelector);
        if (!element) return;

        // Clear any previous interval before setting a new one
        if (marginIntervalId) {
            clearInterval(marginIntervalId);
        }

        const currentUrl = window.location.href;

        if (currentUrl.includes('/watch')) {
            // Apply styles for the video page (non-fullscreen)
            element.style.marginTop = '6rem';
            marginIntervalId = setInterval(() => {
                element.style.marginLeft = '0rem';
            }, 100);
        } else {
            // Apply styles for the main page
            element.style.marginTop = '3.7rem';
            marginIntervalId = setInterval(() => {
                element.style.marginLeft = '0rem';
            }, 100);
        }
    };

    // Handles entering and exiting fullscreen
    const handleFullscreenChange = () => {
        const element = document.querySelector(targetSelector);
        if (!element) return;

        // 'document.fullscreenElement' is non-null if the browser is in fullscreen
        if (document.fullscreenElement) {
            // --- ENTERING FULLSCREEN ---
            // Stop the margin adjustment interval, as it's not needed
            if (marginIntervalId) {
                clearInterval(marginIntervalId);
                marginIntervalId = null;
            }
            // Set the top margin to 0
            element.style.marginTop = '0rem';
        } else {
            // --- EXITING FULLSCREEN ---
            // Re-apply the appropriate default margins based on the current page
            applyDefaultStyles();
        }
    };

    // --- EVENT LISTENERS ---

    // Listens for YouTube's own navigation event (moving between pages)
    window.addEventListener('yt-navigate-finish', applyDefaultStyles);

    // Listens for the browser's fullscreen change event
    document.addEventListener('fullscreenchange', handleFullscreenChange);

    // Runs once on the initial page load to set the first state
    const initialObserver = new MutationObserver((mutationsList, obs) => {
        if (document.querySelector(targetSelector)) {
            applyDefaultStyles();
            obs.disconnect(); // Disconnect after first run
        }
    });

    initialObserver.observe(document.body, {
        childList: true,
        subtree: true
    });
})();