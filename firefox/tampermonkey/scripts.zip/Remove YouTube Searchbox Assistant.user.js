// ==UserScript==
// @name         Remove YouTube Searchbox Assistant
// @namespace    http://tampermonkey.net/
// @version      2025-08-18
// @description  Removes the text input assistant from the YouTube search box
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const targetNode = document.body;

    const config = { childList: true, subtree: true };

    const callback = function(mutationsList, observer) {
        for(const mutation of mutationsList) {
            if (mutation.type === 'childList') {
                const elementToRemove = document.querySelector('div.ytSearchboxComponentYtdTextInputAssistantWrapper');
                if (elementToRemove) {
                    elementToRemove.remove();
                    observer.disconnect();
                }
            }
        }
    };

    const observer = new MutationObserver(callback);

    observer.observe(targetNode, config);
})();