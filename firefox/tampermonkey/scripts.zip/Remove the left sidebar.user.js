// ==UserScript==
// @name         Remove the left sidebar
// @namespace    http://tampermonkey.net/
// @version      2025-08-18.3
// @description  Rigorously removes the left sidebar on YouTube and ensures the main content margin is always correct, even after navigation.
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        GM_addStyle
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // Use GM_addStyle for the most efficient and permanent hiding of the sidebar.
    // This part is static and works perfectly for simply hiding the element.
    GM_addStyle(`
        ytd-mini-guide-renderer {
            display: none !important;
        }
    `);

    /**
     * This function ensures the layout is correct. It needs to be run on page load
     * and after every internal YouTube navigation.
     */
    const adjustLayout = () => {
        const app = document.querySelector('ytd-app');
        const pageManager = document.querySelector('#page-manager.style-scope.ytd-app');

        // 1. Remove the attribute that tells the page to leave space for the mini-guide.
        // YouTube re-adds this attribute on navigation, so we must keep removing it.
        if (app && app.hasAttribute('mini-guide-visible')) {
            app.removeAttribute('mini-guide-visible');
        }

        // 2. Explicitly set the margin on the page manager.
        // This is the KEY FIX: we re-apply this style directly after each navigation,
        // overriding any styles YouTube's own scripts may have just applied.
        if (pageManager) {
            pageManager.style.marginLeft = '0px';
        }
    };

    // YouTube has a custom event 'yt-navigate-finish' that fires after the page
    // content has been updated during an internal navigation (e.g., clicking the logo).
    // Listening for this is the most reliable and efficient method.
    document.addEventListener('yt-navigate-finish', () => {
        // We use a small delay or requestAnimationFrame to ensure our changes apply *after*
        // YouTube has finished its own layout adjustments for the new page.
        requestAnimationFrame(adjustLayout);
    });

    // We still need to handle the very first time the page loads.
    // A MutationObserver is a reliable way to wait for the necessary elements to appear.
    const observer = new MutationObserver(() => {
        if (document.querySelector('#page-manager.style-scope.ytd-app')) {
            // The elements are now on the page, so we can make our initial adjustment.
            adjustLayout();
            // Since the 'yt-navigate-finish' listener will handle all future updates,
            // we can disconnect this observer now. It has served its purpose.
            observer.disconnect();
        }
    });

    // Start observing for the initial page load.
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

})();