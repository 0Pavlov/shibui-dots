// ==UserScript==
// @name         Hide Voice Input Icon
// @namespace    http://tampermonkey.net/
// @version      2025-08-18
// @description  try to take over the world!
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // The function that will be executed when a change is detected
    const callback = function(mutationsList, observer) {
        const voiceSearchButton = document.getElementById('voice-search-button');
        if (voiceSearchButton) {
            // If the button is found, remove it
            voiceSearchButton.remove();
            console.log('Voice search button successfully hidden.');
            // Stop observing now that we've found and removed the button
            observer.disconnect();
        }
    };

    // Create a new observer with the callback function
    const observer = new MutationObserver(callback);

    // Start observing the entire document for changes to the structure
    observer.observe(document.body, { childList: true, subtree: true });
})();