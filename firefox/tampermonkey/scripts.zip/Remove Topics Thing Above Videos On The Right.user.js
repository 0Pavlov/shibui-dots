// ==UserScript==
// @name         Remove Topics Thing Above Videos On The Right
// @namespace    http://tampermonkey.net/
// @version      2025-08-18
// @description  try to take over the world!
// @author       You
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // The CSS selector for the element we want to remove.
    const selectorToRemove = 'yt-related-chip-cloud-renderer';

    const callback = function(mutationsList, observer) {
        // Look for the element on the page
        const relatedChips = document.querySelector(selectorToRemove);

        // If the element exists, remove it and stop the observer.
        if (relatedChips) {
            console.log('Related topics chip cloud found. Removing it.');
            relatedChips.remove();

            // Since this script has only one job, we disconnect the observer
            // after the element is removed to save system resources.
            observer.disconnect();
        }
    };

    // Create a new observer instance with our callback function
    const observer = new MutationObserver(callback);

    // Start observing the entire document for changes, so we can catch
    // when the related chips element is added to the page.
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
})();